print("Hello world")
print("hello world")
print("你好，世界")
print("干啥")
