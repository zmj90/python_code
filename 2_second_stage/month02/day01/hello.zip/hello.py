print("Hello world")
print("Hello world")
print("你好，世界")
print("干啥")
